document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); 
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (email === "" || password === "") {
        alert("Please enter both email and password.");
        return;
    }

    // --- SIMULATED LOGIN ---
    // Use test@bookstore.com and password123 for success
    if (email === "test@bookstore.com" && password === "password123") {
        alert("Login successful! Redirecting to the bookstore...");
        // Redirect to the main home page
        window.location.href = 'home.html'; 
    } else {
        alert("Login failed. Invalid email or password.");
    }
});