document.addEventListener('DOMContentLoaded', () => {
    
    // ----------------------------------------------------
    // 1. BOOK DATA (Source of Truth)
    // ----------------------------------------------------
    const BOOKS_DATA = [
        // Ensure all IDs are unique numbers!
        { id: 1, title: "The Code Weaver", author: "Alan Turing", price: 550.00, category: "Technology", image: "images/book1.jpeg" },
        { id: 2, title: "A Flicker in Time", author: "Clara Barton", price: 499.00, category: "Science", image: "images/book2.jpg" },
        { id: 3, title: "Deep Space Echoes", author: "Dr. Elon Musk", price: 710.00, category: "Science", image: "images/book3.jpg" },
        { id: 4, title: "The Silent City", author: "George Orwell", price: 390.00, category: "Fiction", image: "images/book4.jpg" },
        { id: 5, title: "The Philosopher's Stone", author: "Aristotle", price: 650.00, category: "Non-Fiction", image: "images/book5.jpg" },
        { id: 6, title: "Whispers of the Past", author: "Jane Austen", price: 420.00, category: "Fiction", image: "images/book6.jpg" },
        { id: 7, title: "Modern Algorithms", author: "Donald Knuth", price: 890.00, category: "Technology", image: "images/book7.jpg" },
        { id: 8, title: "The Quantum Realm", author: "Neil deGrasse Tyson", price: 770.00, category: "Science", image: "images/book8.jpg" },
        { id: 9, title: "Beyond the Horizon", author: "Jules Verne", price: 515.00, category: "Fiction", image: "images/book9.jpg" },
        { id: 10, title: "The Last Sentinel", author: "H.P. Lovecraft", price: 455.00, category: "Fiction", image: "images/book10.jpg" },
        { id: 11, title: "Principles of Design", author: "Leonardo da Vinci", price: 999.00, category: "Technology", image: "images/book11.jpg" },
        { id: 12, title: "Historical Revolutions", author: "Herodotus", price: 580.00, category: "Science", image: "images/book12.jpg" },
        { id: 13, title: "The Golden Age", author: "F. Scott Fitzgerald", price: 380.00, category: "Non-Fiction", image: "images/book13.jpg" },
        { id: 14, title: "The Python Master", author: "Guido van Rossum", price: 790.00, category: "Technology", image: "images/book14.jpg" },
        { id: 15, title: "The Cosmic Dance", author: "Carl Sagan", price: 685.00, category: "Science", image: "images/book15.jpg" },
        { id: 16, title: "Future Shock", author: "Aldous Huxley", price: 530.00, category: "Non-Fiction", image: "images/book16.jpg" },
        { id: 17, title: "The Art of War", author: "Sun Tzu", price: 299.00, category: "Non-Fiction", image: "images/book17.jpg" },
        { id: 18, title: "The Time Traveller", author: "H.G. Wells", price: 410.00, category: "Fiction", image: "images/book18.jpg" },
        { id: 19, title: "Digital Fortress", author: "Dan Brown", price: 475.00, category: "Technology", image: "images/book19.jpg" },
        { id: 20, title: "The Secret History", author: "Donna Tartt", price: 590.00, category: "Non-Fiction", image: "images/book20.jpg" }
    ];

    // ----------------------------------------------------
    // 2. GLOBAL STATE AND CORE FUNCTIONS
    // ----------------------------------------------------
    let cart = [];

    // Make renderBooks globally accessible for the onclick events in home.html
    window.renderBooks = renderBooks; 

    /**
     * Renders book cards based on the filterCategory.
     */
    function renderBooks(filterCategory = 'All Books') {
        const booksContainer = document.getElementById('books-container');
        const categoryHeading = document.getElementById('category-heading');
        
        categoryHeading.textContent = filterCategory;

        const filteredBooks = BOOKS_DATA.filter(book => 
            filterCategory === 'All Books' || book.category === filterCategory
        );

        booksContainer.innerHTML = '';
        
        filteredBooks.forEach(book => {
            const bookCard = document.createElement('div');
            bookCard.classList.add('book-card');
            
            // CRITICAL: Storing the book ID as a data attribute
            bookCard.setAttribute('data-id', book.id); 

            bookCard.innerHTML = `
                <img src="${book.image}" alt="${book.title}" class="book-cover">
                <div class="book-info">
                    <h4 class="book-title">${book.title}</h4>
                    <p class="book-author">${book.author}</p>
                    <p class="book-price">₹${book.price.toFixed(2)}</p>
                    <button class="add-to-cart">Add to Cart</button>
                </div>
            `;
            booksContainer.appendChild(bookCard);
        });

        // CRITICAL FIX: Re-attach 'Add to Cart' listeners after rendering
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', handleAddToCart);
        });
    }

    function getBookById(id) {
        return BOOKS_DATA.find(book => book.id === id); 
    }
    
    function calculateCartTotal() {
        return cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);
    }

    function renderCart() {
        // Retrieve all necessary HTML elements
        const container = document.getElementById('cart-items-container');
        const totalMoneySpan = document.getElementById('cart-total-money');
        const cartCountSpan = document.getElementById('cart-count');
        const checkoutBtn = document.getElementById('checkoutBtn');
        const emptyMsg = document.getElementById('empty-cart-message');
        
        // Error Check: Ensures the script doesn't fail if an ID is misspelled in home.html
        if (!container || !totalMoneySpan || !cartCountSpan || !checkoutBtn || !emptyMsg) {
             console.error("Cart rendering failed: One or more critical HTML IDs are missing or misspelled in home.html. Please check your IDs.");
             return; 
        }

        container.innerHTML = ''; 
        
        if (cart.length === 0) {
            totalMoneySpan.textContent = '₹0.00';
            cartCountSpan.textContent = 0;
            checkoutBtn.disabled = true;
            emptyMsg.style.display = 'block'; 
            return;
        }

        emptyMsg.style.display = 'none';

        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');
            itemElement.innerHTML = `
                <div class="cart-item-details">
                    <strong>${item.title}</strong>
                    <span>${item.author}</span>
                </div>
                <div>
                    <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                    <button class="delete-item-btn" data-item-id="${item.id}">Delete</button>
                </div>
            `;
            container.appendChild(itemElement);
        });

        const total = calculateCartTotal();
        totalMoneySpan.textContent = `₹${total}`;
        cartCountSpan.textContent = cart.length;
        checkoutBtn.disabled = false;
        
        // Re-attach delete listeners
        document.querySelectorAll('.delete-item-btn').forEach(button => {
            button.addEventListener('click', handleDeleteItem);
        });
    }

    // ----------------------------------------------------
    // 3. ACTION HANDLERS
    // ----------------------------------------------------
    function handleAddToCart(event) {
        const button = event.target;
        const bookCard = button.closest('.book-card');
        
        if (!bookCard) return; 

        // CRITICAL: Get the ID and find the data
        const bookId = parseInt(bookCard.getAttribute('data-id')); 
        const bookData = getBookById(bookId);
        
        if (bookData) {
            const newCartItem = {
                id: Date.now() + Math.random(), // Unique ID for THIS instance in the cart
                title: bookData.title,
                author: bookData.author,
                price: bookData.price,
                quantity: 1
            };
            
            // This is the line that ADDS the item to the cart array
            cart.push(newCartItem); 
            
            renderCart();
            alert(`"${bookData.title}" added to cart!`);

        } else {
             console.error("Book data not found for ID:", bookId);
        }
    }

    function handleDeleteItem(event) {
        const itemId = parseFloat(event.target.dataset.itemId);
        cart = cart.filter(item => item.id !== itemId);
        renderCart();
    }
    
    function handleCheckout() {
        const total = calculateCartTotal();
        if (total === '0.00') {
            alert("Your cart is empty. Please add items before checking out.");
            return;
        }
        
        alert(`Proceeding to buy ${cart.length} items for a total of ₹${total}. Thank you for your order!`);
        
        cart = [];
        renderCart();
        document.getElementById('shoppingCart').classList.remove('open');
    }

    // ----------------------------------------------------
    // 4. INITIALIZATION AND EVENT LISTENERS
    // ----------------------------------------------------

    document.getElementById('openCartBtn').addEventListener('click', (e) => {
        e.preventDefault();
        document.getElementById('shoppingCart').classList.add('open');
    });

    document.getElementById('closeCartBtn').addEventListener('click', () => {
        document.getElementById('shoppingCart').classList.remove('open');
    });

    document.getElementById('checkoutBtn').addEventListener('click', handleCheckout);

    // Initial render: show all books when the page loads
    renderBooks('All Books'); 
    renderCart(); 
});